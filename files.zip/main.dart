import 'package:flutter/material.dart';
import 'models/wear_task.dart';
import 'screens/task_list_screen.dart';
import 'theme/wear_colors.dart';

void main() {
  runApp(const HomeTasksWearApp());
}

class HomeTasksWearApp extends StatelessWidget {
  const HomeTasksWearApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HomeTasks Wear',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: WearColors.background,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: WearColors.headerTeal,
          primary: WearColors.headerTeal,
        ),
      ),
      // TODO: reemplaza estos datos de ejemplo por WearTaskRepository()
      // .getMyTasks(userId) una vez que tengas el token/userId
      // transferidos desde la app de teléfono. Ver README.md.
      home: TaskListScreen(
        userName: 'Sofía',
        initialTasks: const [
          WearTask(
            id: '1',
            title: 'ORDENAR SU CUARTO',
            timeLabel: '16:00 hrs',
            icon: Icons.bed_outlined,
          ),
          WearTask(
            id: '2',
            title: 'HACER LOS DEBERES',
            timeLabel: '17:00 hrs',
            icon: Icons.menu_book_outlined,
          ),
          WearTask(
            id: '3',
            title: 'PRACTICAR GUITARRA',
            timeLabel: '18:30 hrs',
            icon: Icons.music_note_outlined,
          ),
        ],
      ),
    );
  }
}
