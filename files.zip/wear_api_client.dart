import 'package:dio/dio.dart';

/// Cliente HTTP del reloj. Apunta al MISMO backend que tu app de teléfono,
/// así que ambos consumen exactamente la misma API y la misma base de datos.
///
/// El token JWT no se genera aquí: en la mayoría de los casos el usuario
/// ya inició sesión en el teléfono, así que el token debe transferirse
/// al reloj (por ejemplo vía la Wearable Data Layer API, o pidiéndolo
/// una sola vez con un login simplificado en el reloj). Ver README.md.
class WearApiClient {
  WearApiClient._internal() {
    _dio = Dio(
      BaseOptions(
        baseUrl: baseUrl,
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
      ),
    );
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          handler.next(options);
        },
      ),
    );
  }

  static final WearApiClient instance = WearApiClient._internal();

  static const String baseUrl =
      'https://organizadortareasback.onrender.com/api';

  late final Dio _dio;
  Dio get dio => _dio;

  // Igual que en el teléfono: token en memoria, seteado tras recibir
  // la sesión transferida desde la app móvil.
  String? token;
  String? userId;
}
