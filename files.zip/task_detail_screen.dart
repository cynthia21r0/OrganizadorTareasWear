import 'package:flutter/material.dart';
import '../models/wear_task.dart';
import '../theme/wear_colors.dart';
import 'starting_task_screen.dart';

class TaskDetailScreen extends StatelessWidget {
  final WearTask task;
  final String userName;
  final String? avatarUrl; // foto de perfil del usuario asignado (opcional)
  final ValueChanged<WearTask> onTaskUpdated;

  const TaskDetailScreen({
    super.key,
    required this.task,
    required this.userName,
    required this.onTaskUpdated,
    this.avatarUrl,
  });

  void _markCompletedDirectly(BuildContext context) {
    onTaskUpdated(task.copyWith(status: WearTaskStatus.completada));
    Navigator.of(context).pop();
  }

  void _startTask(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StartingTaskScreen(
          task: task,
          onTaskUpdated: onTaskUpdated,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WearColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [WearColors.headerTeal, WearColors.headerTealDark],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                children: [
                  const Text(
                    'TAREA',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    userName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 26,
                      backgroundColor: WearColors.headerTeal.withOpacity(0.15),
                      backgroundImage: avatarUrl != null ? NetworkImage(avatarUrl!) : null,
                      child: avatarUrl == null
                          ? Text(
                              userName.isNotEmpty ? userName[0].toUpperCase() : '?',
                              style: const TextStyle(
                                color: WearColors.headerTealDark,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            )
                          : null,
                    ),
                    const SizedBox(height: 14),
                    Icon(task.icon, color: WearColors.headerTealDark, size: 30),
                    const SizedBox(height: 10),
                    Text(
                      task.title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.bold,
                        color: WearColors.textNavy,
                        height: 1.25,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      task.timeLabel,
                      style: const TextStyle(fontSize: 12, color: WearColors.textSecondary),
                    ),
                    const SizedBox(height: 20),
                    _PillButton(
                      label: 'MARCAR COMO COMPLETADA',
                      filled: true,
                      onTap: () => _markCompletedDirectly(context),
                    ),
                    const SizedBox(height: 10),
                    _PillButton(
                      label: 'COMENZAR',
                      filled: false,
                      onTap: () => _startTask(context),
                    ),
                    const SizedBox(height: 10),
                    _PillButton(
                      label: '← VOLVER',
                      filled: false,
                      bare: true,
                      onTap: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PillButton extends StatelessWidget {
  final String label;
  final bool filled;
  final bool bare; // sin borde, solo texto (como "← Volver")
  final VoidCallback onTap;

  const _PillButton({
    required this.label,
    required this.filled,
    required this.onTap,
    this.bare = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: filled ? WearColors.headerTeal : Colors.white,
          foregroundColor: filled ? Colors.white : WearColors.headerTealDark,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 13),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
            side: bare
                ? BorderSide.none
                : BorderSide(
                    color: filled ? Colors.transparent : WearColors.headerTeal,
                    width: 1.4,
                  ),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
            color: bare ? WearColors.textSecondary : null,
          ),
        ),
      ),
    );
  }
}
