import 'package:flutter/material.dart';

enum WearTaskStatus { pendiente, completada }

/// Versión simplificada de TaskModel pensada para pantallas de reloj.
/// Si ya tienes `task_model.dart` en tu app de teléfono, puedes mapear
/// ese modelo a este (ver WearTask.fromApiJson) en vez de duplicar campos.
class WearTask {
  final String id;
  final String title;
  final String timeLabel; // ej. "16:00 hrs", ya formateado
  final IconData icon;
  final WearTaskStatus status;

  const WearTask({
    required this.id,
    required this.title,
    required this.timeLabel,
    required this.icon,
    this.status = WearTaskStatus.pendiente,
  });

  WearTask copyWith({WearTaskStatus? status}) {
    return WearTask(
      id: id,
      title: title,
      timeLabel: timeLabel,
      icon: icon,
      status: status ?? this.status,
    );
  }

  /// Mapea la respuesta JSON de tu API NestJS (misma forma que usa
  /// tu TaskModel en el teléfono) a este modelo reducido para el reloj.
  factory WearTask.fromApiJson(Map<String, dynamic> json) {
    return WearTask(
      id: json['id'] as String,
      title: (json['title'] as String).toUpperCase(),
      timeLabel: _formatTime(json['dueDate'] as String),
      icon: _iconForTitle(json['title'] as String),
      status: json['status'] == 'completada'
          ? WearTaskStatus.completada
          : WearTaskStatus.pendiente,
    );
  }

  static String _formatTime(String isoDate) {
    final date = DateTime.parse(isoDate).toLocal();
    final hour = date.hour.toString().padLeft(2, '0');
    final minute = date.minute.toString().padLeft(2, '0');
    return '$hour:$minute hrs';
  }

  /// Heurística simple de ícono según palabras clave del título.
  /// Reemplázala por tus propios íconos ilustrados si los tienes en assets.
  static IconData _iconForTitle(String title) {
    final t = title.toLowerCase();
    if (t.contains('cuarto') || t.contains('cama') || t.contains('ordenar')) {
      return Icons.bed_outlined;
    }
    if (t.contains('deber') || t.contains('tarea') || t.contains('estudi')) {
      return Icons.menu_book_outlined;
    }
    if (t.contains('guitarra') || t.contains('música') || t.contains('musica')) {
      return Icons.music_note_outlined;
    }
    if (t.contains('platos') || t.contains('cocina')) {
      return Icons.local_dining_outlined;
    }
    if (t.contains('basura')) {
      return Icons.delete_outline;
    }
    return Icons.check_circle_outline;
  }
}
